#include "dlgmask.h"
#include "ui_dlgmask.h"
#include <QSettings>

DlgMask::DlgMask(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DlgMask)
{
    ui->setupUi(this);
   // mMask=QImage(1920,1080,QImage::Format_ARGB32_Premultiplied);
   // mMask.fill(qRgba(0,0,0,0));

    QSettings *configIniRead = new QSettings("maskdata.ini", QSettings::IniFormat);
    //����ȡ����ini�ļ�������QString�У���ȡֵ��Ȼ��ͨ��toString()����ת����QString����
    ui->pushButton->setText(configIniRead->value("/mask/one").toString());
    ui->pushButton_2->setText(configIniRead->value("/mask/two").toString());
    ui->pushButton_3->setText(configIniRead->value("/mask/three").toString());
    ui->pushButton_4->setText(configIniRead->value("/mask/four").toString());
    ui->pushButton_5->setText(configIniRead->value("/mask/five").toString());
    ui->pushButton_6->setText(configIniRead->value("/mask/six").toString());
    ui->pushButton_7->setText(configIniRead->value("/mask/seven").toString());
    ui->pushButton_8->setText(configIniRead->value("/mask/eight").toString());
    ui->pushButton_9->setText(configIniRead->value("/mask/nine").toString());
    ui->pushButton_10->setText(configIniRead->value("/mask/onezero").toString());
    ui->pushButton_11->setText(configIniRead->value("/mask/oneone").toString());
    ui->pushButton_12->setText(configIniRead->value("/mask/onetwo").toString());
    ui->pushButton_13->setText(configIniRead->value("/mask/onethree").toString());
    ui->pushButton_14->setText(configIniRead->value("/mask/onefour").toString());
    ui->pushButton_15->setText(configIniRead->value("/mask/onefive").toString());
    ui->pushButton_16->setText(configIniRead->value("/mask/onesix").toString());
    ui->pushButton_17->setText(configIniRead->value("/mask/oneseven").toString());
    ui->pushButton_18->setText(configIniRead->value("/mask/oneeight").toString());
    ui->pushButton_19->setText(configIniRead->value("/mask/onenine").toString());
    ui->pushButton_20->setText(configIniRead->value("/mask/twozero").toString());
    ui->pushButton_21->setText(configIniRead->value("/mask/twoone").toString());
    ui->pushButton_22->setText(configIniRead->value("/mask/twotwo").toString());
    ui->pushButton_23->setText(configIniRead->value("/mask/twothree").toString());
    ui->pushButton_24->setText(configIniRead->value("/mask/twofour").toString());
    ui->pushButton_25->setText(configIniRead->value("/mask/twofive").toString());
    ui->pushButton_26->setText(configIniRead->value("/mask/twosix").toString());
    ui->pushButton_27->setText(configIniRead->value("/mask/twoseven").toString());
    ui->pushButton_28->setText(configIniRead->value("/mask/twoeight").toString());
    ui->pushButton_29->setText(configIniRead->value("/mask/twonine").toString());
    ui->pushButton_30->setText(configIniRead->value("/mask/threezero").toString());
    ui->pushButton_31->setText(configIniRead->value("/mask/threeone").toString());
    ui->pushButton_32->setText(configIniRead->value("/mask/threetwo").toString());
    ui->pushButton_33->setText(configIniRead->value("/mask/threethree").toString());
    ui->pushButton_34->setText(configIniRead->value("/mask/threefour").toString());
    ui->pushButton_35->setText(configIniRead->value("/mask/threefive").toString());
    ui->pushButton_36->setText(configIniRead->value("/mask/threesix").toString());
    ui->pushButton_37->setText(configIniRead->value("/mask/threeseven").toString());
    ui->pushButton_38->setText(configIniRead->value("/mask/threeeight").toString());
    ui->pushButton_39->setText(configIniRead->value("/mask/threenine").toString());
    ui->pushButton_40->setText(configIniRead->value("/mask/fourzero").toString());
    ui->pushButton_41->setText(configIniRead->value("/mask/fourone").toString());
    ui->pushButton_42->setText(configIniRead->value("/mask/fourtwo").toString());
    ui->pushButton_43->setText(configIniRead->value("/mask/fourthree").toString());
    ui->pushButton_44->setText(configIniRead->value("/mask/fourfour").toString());
    ui->pushButton_45->setText(configIniRead->value("/mask/fourfive").toString());
    ui->pushButton_46->setText(configIniRead->value("/mask/foursix").toString());
    ui->pushButton_47->setText(configIniRead->value("/mask/fourseven").toString());
    ui->pushButton_48->setText(configIniRead->value("/mask/foureight").toString());
    ui->pushButton_49->setText(configIniRead->value("/mask/fournine").toString());
    ui->pushButton_50->setText(configIniRead->value("/mask/fivezero").toString());
    ui->pushButton_51->setText(configIniRead->value("/mask/fiveone").toString());
    ui->pushButton_52->setText(configIniRead->value("/mask/fivetwo").toString());
    ui->pushButton_53->setText(configIniRead->value("/mask/fivethree").toString());
    ui->pushButton_54->setText(configIniRead->value("/mask/fivefour").toString());
    ui->pushButton_55->setText(configIniRead->value("/mask/fivefive").toString());
    ui->pushButton_56->setText(configIniRead->value("/mask/fivesix").toString());
    ui->pushButton_57->setText(configIniRead->value("/mask/fiveseven").toString());
    ui->pushButton_58->setText(configIniRead->value("/mask/fiveeight").toString());
    ui->pushButton_59->setText(configIniRead->value("/mask/fivenine").toString());
    ui->pushButton_60->setText(configIniRead->value("/mask/sixzero").toString());
    ui->pushButton_61->setText(configIniRead->value("/mask/sixone").toString());
    ui->pushButton_62->setText(configIniRead->value("/mask/sixtwo").toString());
    ui->pushButton_63->setText(configIniRead->value("/mask/sixthree").toString());
    ui->pushButton_64->setText(configIniRead->value("/mask/sixfour").toString());
    ui->pushButton_65->setText(configIniRead->value("/mask/sixfive").toString());
    ui->pushButton_66->setText(configIniRead->value("/mask/sixsix").toString());
    ui->pushButton_67->setText(configIniRead->value("/mask/sixseven").toString());
    ui->pushButton_68->setText(configIniRead->value("/mask/sixeight").toString());
    ui->pushButton_69->setText(configIniRead->value("/mask/sixnine").toString());
    ui->pushButton_70->setText(configIniRead->value("/mask/sevenzero").toString());
    ui->pushButton_71->setText(configIniRead->value("/mask/sevenone").toString());
    ui->pushButton_72->setText(configIniRead->value("/mask/seventwo").toString());
    ui->pushButton_73->setText(configIniRead->value("/mask/seventhree").toString());
    ui->pushButton_74->setText(configIniRead->value("/mask/sevenfour").toString());
    ui->pushButton_75->setText(configIniRead->value("/mask/sevenfive").toString());
    ui->pushButton_76->setText(configIniRead->value("/mask/sevensix").toString());
    ui->pushButton_77->setText(configIniRead->value("/mask/sevenseven").toString());
    ui->pushButton_78->setText(configIniRead->value("/mask/seveneight").toString());
    ui->pushButton_79->setText(configIniRead->value("/mask/sevennine").toString());
    ui->pushButton_80->setText(configIniRead->value("/mask/eightzero").toString());
    ui->pushButton_81->setText(configIniRead->value("/mask/eightone").toString());
    ui->pushButton_82->setText(configIniRead->value("/mask/eighttwo").toString());
    ui->pushButton_83->setText(configIniRead->value("/mask/eightthree").toString());
    ui->pushButton_84->setText(configIniRead->value("/mask/eightfour").toString());
    ui->pushButton_85->setText(configIniRead->value("/mask/eightfive").toString());
    ui->pushButton_86->setText(configIniRead->value("/mask/eightsix").toString());
    ui->pushButton_87->setText(configIniRead->value("/mask/eightseven").toString());
    ui->pushButton_88->setText(configIniRead->value("/mask/eighteight").toString());
    ui->pushButton_89->setText(configIniRead->value("/mask/eightnine").toString());
    ui->pushButton_90->setText(configIniRead->value("/mask/ninezero").toString());
    ui->pushButton_91->setText(configIniRead->value("/mask/nineone").toString());
    ui->pushButton_92->setText(configIniRead->value("/mask/ninetwo").toString());
    ui->pushButton_93->setText(configIniRead->value("/mask/ninethree").toString());
    ui->pushButton_94->setText(configIniRead->value("/mask/ninefour").toString());
    ui->pushButton_95->setText(configIniRead->value("/mask/ninefive").toString());
    ui->pushButton_96->setText(configIniRead->value("/mask/ninesix").toString());
    ui->pushButton_97->setText(configIniRead->value("/mask/nineseven").toString());
    ui->pushButton_98->setText(configIniRead->value("/mask/nineeight").toString());
    ui->pushButton_99->setText(configIniRead->value("/mask/ninenine").toString());
    ui->pushButton_100->setText(configIniRead->value("/mask/onezerozero").toString());
    ui->pushButton_101->setText(configIniRead->value("/mask/onezeroone").toString());
    ui->pushButton_102->setText(configIniRead->value("/mask/onezerotwo").toString());
    ui->pushButton_103->setText(configIniRead->value("/mask/onezerothree").toString());
    ui->pushButton_104->setText(configIniRead->value("/mask/onezerofour").toString());
    ui->pushButton_105->setText(configIniRead->value("/mask/onezerofive").toString());
    ui->pushButton_106->setText(configIniRead->value("/mask/onezerosix").toString());
    ui->pushButton_107->setText(configIniRead->value("/mask/onezeroseven").toString());
    ui->pushButton_108->setText(configIniRead->value("/mask/onezeroeight").toString());
    ui->pushButton_109->setText(configIniRead->value("/mask/onezeronine").toString());
    ui->pushButton_110->setText(configIniRead->value("/mask/oneonezero").toString());
    ui->pushButton_111->setText(configIniRead->value("/mask/oneoneone").toString());
    ui->pushButton_112->setText(configIniRead->value("/mask/oneonetwo").toString());
    ui->pushButton_113->setText(configIniRead->value("/mask/oneonethree").toString());
    ui->pushButton_114->setText(configIniRead->value("/mask/oneonefour").toString());
    ui->pushButton_115->setText(configIniRead->value("/mask/oneonefive").toString());
    ui->pushButton_116->setText(configIniRead->value("/mask/oneonesix").toString());
    ui->pushButton_117->setText(configIniRead->value("/mask/oneoneseven").toString());
    ui->pushButton_118->setText(configIniRead->value("/mask/oneoneeight").toString());
    ui->pushButton_119->setText(configIniRead->value("/mask/oneonenine").toString());
    ui->pushButton_120->setText(configIniRead->value("/mask/onetwozero").toString());
    ui->pushButton_121->setText(configIniRead->value("/mask/onetwoone").toString());
    ui->pushButton_122->setText(configIniRead->value("/mask/onetwotwo").toString());
    ui->pushButton_123->setText(configIniRead->value("/mask/onetwothree").toString());
    ui->pushButton_124->setText(configIniRead->value("/mask/onetwofour").toString());
    ui->pushButton_125->setText(configIniRead->value("/mask/onetwofive").toString());
    ui->pushButton_126->setText(configIniRead->value("/mask/onetwosix").toString());
    ui->pushButton_127->setText(configIniRead->value("/mask/onetwoseven").toString());
    ui->pushButton_128->setText(configIniRead->value("/mask/onetwoeight").toString());
    ui->pushButton_129->setText(configIniRead->value("/mask/onetwonine").toString());
    ui->pushButton_130->setText(configIniRead->value("/mask/onethreezero").toString());
    ui->pushButton_131->setText(configIniRead->value("/mask/onethreeone").toString());
    ui->pushButton_132->setText(configIniRead->value("/mask/onethreetwo").toString());
    ui->pushButton_133->setText(configIniRead->value("/mask/onethreethree").toString());
    ui->pushButton_134->setText(configIniRead->value("/mask/onethreefour").toString());
    ui->pushButton_135->setText(configIniRead->value("/mask/onethreefive").toString());
    ui->pushButton_136->setText(configIniRead->value("/mask/onethreesix").toString());
    ui->pushButton_137->setText(configIniRead->value("/mask/onethreeseven").toString());
    ui->pushButton_138->setText(configIniRead->value("/mask/onethreeeight").toString());
    ui->pushButton_139->setText(configIniRead->value("/mask/onethreenine").toString());
    ui->pushButton_140->setText(configIniRead->value("/mask/onefourzero").toString());
    ui->pushButton_141->setText(configIniRead->value("/mask/onefourone").toString());
    ui->pushButton_142->setText(configIniRead->value("/mask/onefourtwo").toString());
    ui->pushButton_143->setText(configIniRead->value("/mask/onefourthree").toString());
    ui->pushButton_144->setText(configIniRead->value("/mask/onefourfour").toString());
    //��������ɺ�ɾ��ָ��
    delete configIniRead;
}

DlgMask::~DlgMask()
{
    delete ui;
}

void DlgMask::on_comboBox_activated(const QString &arg1)
{
    if(arg1=="5")
    {
        ui->pushButton->multiple=5;
        ui->pushButton_2->multiple=5;
        ui->pushButton_3->multiple=5;
        ui->pushButton_4->multiple=5;
        ui->pushButton_5->multiple=5;
        ui->pushButton_6->multiple=5;
        ui->pushButton_7->multiple=5;
        ui->pushButton_8->multiple=5;
        ui->pushButton_9->multiple=5;
        ui->pushButton_10->multiple=5;
        ui->pushButton_11->multiple=5;
        ui->pushButton_12->multiple=5;
        ui->pushButton_13->multiple=5;
        ui->pushButton_14->multiple=5;
        ui->pushButton_15->multiple=5;
        ui->pushButton_16->multiple=5;
        ui->pushButton_17->multiple=5;
        ui->pushButton_18->multiple=5;
        ui->pushButton_19->multiple=5;
        ui->pushButton_20->multiple=5;
        ui->pushButton_21->multiple=5;
        ui->pushButton_22->multiple=5;
        ui->pushButton_23->multiple=5;
        ui->pushButton_24->multiple=5;
        ui->pushButton_25->multiple=5;
        ui->pushButton_26->multiple=5;
        ui->pushButton_27->multiple=5;
        ui->pushButton_28->multiple=5;
        ui->pushButton_29->multiple=5;
        ui->pushButton_30->multiple=5;
        ui->pushButton_31->multiple=5;
        ui->pushButton_32->multiple=5;
        ui->pushButton_33->multiple=5;
        ui->pushButton_34->multiple=5;
        ui->pushButton_35->multiple=5;
        ui->pushButton_36->multiple=5;
        ui->pushButton_37->multiple=5;
        ui->pushButton_38->multiple=5;
        ui->pushButton_39->multiple=5;
        ui->pushButton_40->multiple=5;
        ui->pushButton_41->multiple=5;
        ui->pushButton_42->multiple=5;
        ui->pushButton_43->multiple=5;
        ui->pushButton_44->multiple=5;
        ui->pushButton_45->multiple=5;
        ui->pushButton_46->multiple=5;
        ui->pushButton_47->multiple=5;
        ui->pushButton_48->multiple=5;
        ui->pushButton_49->multiple=5;
        ui->pushButton_50->multiple=5;
        ui->pushButton_51->multiple=5;
        ui->pushButton_52->multiple=5;
        ui->pushButton_53->multiple=5;
        ui->pushButton_54->multiple=5;
        ui->pushButton_55->multiple=5;
        ui->pushButton_56->multiple=5;
        ui->pushButton_57->multiple=5;
        ui->pushButton_58->multiple=5;
        ui->pushButton_59->multiple=5;
        ui->pushButton_60->multiple=5;
        ui->pushButton_61->multiple=5;
        ui->pushButton_62->multiple=5;
        ui->pushButton_63->multiple=5;
        ui->pushButton_64->multiple=5;
        ui->pushButton_65->multiple=5;
        ui->pushButton_66->multiple=5;
        ui->pushButton_67->multiple=5;
        ui->pushButton_68->multiple=5;
        ui->pushButton_69->multiple=5;
        ui->pushButton_70->multiple=5;
        ui->pushButton_71->multiple=5;
        ui->pushButton_72->multiple=5;
        ui->pushButton_73->multiple=5;
        ui->pushButton_74->multiple=5;
        ui->pushButton_75->multiple=5;
        ui->pushButton_76->multiple=5;
        ui->pushButton_77->multiple=5;
        ui->pushButton_78->multiple=5;
        ui->pushButton_79->multiple=5;
        ui->pushButton_80->multiple=5;
        ui->pushButton_81->multiple=5;
        ui->pushButton_82->multiple=5;
        ui->pushButton_83->multiple=5;
        ui->pushButton_84->multiple=5;
        ui->pushButton_85->multiple=5;
        ui->pushButton_86->multiple=5;
        ui->pushButton_87->multiple=5;
        ui->pushButton_88->multiple=5;
        ui->pushButton_89->multiple=5;
        ui->pushButton_90->multiple=5;
        ui->pushButton_91->multiple=5;
        ui->pushButton_92->multiple=5;
        ui->pushButton_93->multiple=5;
        ui->pushButton_94->multiple=5;
        ui->pushButton_95->multiple=5;
        ui->pushButton_96->multiple=5;
        ui->pushButton_97->multiple=5;
        ui->pushButton_98->multiple=5;
        ui->pushButton_99->multiple=5;
        ui->pushButton_100->multiple=5;
        ui->pushButton_101->multiple=5;
        ui->pushButton_102->multiple=5;
        ui->pushButton_103->multiple=5;
        ui->pushButton_104->multiple=5;
        ui->pushButton_105->multiple=5;
        ui->pushButton_106->multiple=5;
        ui->pushButton_107->multiple=5;
        ui->pushButton_108->multiple=5;
        ui->pushButton_109->multiple=5;
        ui->pushButton_110->multiple=5;
        ui->pushButton_111->multiple=5;
        ui->pushButton_112->multiple=5;
        ui->pushButton_113->multiple=5;
        ui->pushButton_114->multiple=5;
        ui->pushButton_115->multiple=5;
        ui->pushButton_116->multiple=5;
        ui->pushButton_117->multiple=5;
        ui->pushButton_118->multiple=5;
        ui->pushButton_119->multiple=5;
        ui->pushButton_120->multiple=5;
        ui->pushButton_121->multiple=5;
        ui->pushButton_122->multiple=5;
        ui->pushButton_123->multiple=5;
        ui->pushButton_124->multiple=5;
        ui->pushButton_125->multiple=5;
        ui->pushButton_126->multiple=5;
        ui->pushButton_127->multiple=5;
        ui->pushButton_128->multiple=5;
        ui->pushButton_129->multiple=5;
        ui->pushButton_130->multiple=5;
        ui->pushButton_131->multiple=5;
        ui->pushButton_132->multiple=5;
        ui->pushButton_133->multiple=5;
        ui->pushButton_134->multiple=5;
        ui->pushButton_135->multiple=5;
        ui->pushButton_136->multiple=5;
        ui->pushButton_137->multiple=5;
        ui->pushButton_138->multiple=5;
        ui->pushButton_139->multiple=5;
        ui->pushButton_140->multiple=5;
        ui->pushButton_141->multiple=5;
        ui->pushButton_142->multiple=5;
        ui->pushButton_143->multiple=5;
        ui->pushButton_144->multiple=5;
    }
   else if(arg1=="50")
    {
        ui->pushButton->multiple=50;
        ui->pushButton_2->multiple=50;
        ui->pushButton_3->multiple=50;
        ui->pushButton_4->multiple=50;
        ui->pushButton_5->multiple=50;
        ui->pushButton_6->multiple=50;
        ui->pushButton_7->multiple=50;
        ui->pushButton_8->multiple=50;
        ui->pushButton_9->multiple=50;
        ui->pushButton_10->multiple=50;
        ui->pushButton_11->multiple=50;
        ui->pushButton_12->multiple=50;
        ui->pushButton_13->multiple=50;
        ui->pushButton_14->multiple=50;
        ui->pushButton_15->multiple=50;
        ui->pushButton_16->multiple=50;
        ui->pushButton_17->multiple=50;
        ui->pushButton_18->multiple=50;
        ui->pushButton_19->multiple=50;
        ui->pushButton_20->multiple=50;
        ui->pushButton_21->multiple=50;
        ui->pushButton_22->multiple=50;
        ui->pushButton_23->multiple=50;
        ui->pushButton_24->multiple=50;
        ui->pushButton_25->multiple=50;
        ui->pushButton_26->multiple=50;
        ui->pushButton_27->multiple=50;
        ui->pushButton_28->multiple=50;
        ui->pushButton_29->multiple=50;
        ui->pushButton_30->multiple=50;
        ui->pushButton_31->multiple=50;
        ui->pushButton_32->multiple=50;
        ui->pushButton_33->multiple=50;
        ui->pushButton_34->multiple=50;
        ui->pushButton_35->multiple=50;
        ui->pushButton_36->multiple=50;
        ui->pushButton_37->multiple=50;
        ui->pushButton_38->multiple=50;
        ui->pushButton_39->multiple=50;
        ui->pushButton_40->multiple=50;
        ui->pushButton_41->multiple=50;
        ui->pushButton_42->multiple=50;
        ui->pushButton_43->multiple=50;
        ui->pushButton_44->multiple=50;
        ui->pushButton_45->multiple=50;
        ui->pushButton_46->multiple=50;
        ui->pushButton_47->multiple=50;
        ui->pushButton_48->multiple=50;
        ui->pushButton_49->multiple=50;
        ui->pushButton_50->multiple=50;
        ui->pushButton_51->multiple=50;
        ui->pushButton_52->multiple=50;
        ui->pushButton_53->multiple=50;
        ui->pushButton_54->multiple=50;
        ui->pushButton_55->multiple=50;
        ui->pushButton_56->multiple=50;
        ui->pushButton_57->multiple=50;
        ui->pushButton_58->multiple=50;
        ui->pushButton_59->multiple=50;
        ui->pushButton_60->multiple=50;
        ui->pushButton_61->multiple=50;
        ui->pushButton_62->multiple=50;
        ui->pushButton_63->multiple=50;
        ui->pushButton_64->multiple=50;
        ui->pushButton_65->multiple=50;
        ui->pushButton_66->multiple=50;
        ui->pushButton_67->multiple=50;
        ui->pushButton_68->multiple=50;
        ui->pushButton_69->multiple=50;
        ui->pushButton_70->multiple=50;
        ui->pushButton_71->multiple=50;
        ui->pushButton_72->multiple=50;
        ui->pushButton_73->multiple=50;
        ui->pushButton_74->multiple=50;
        ui->pushButton_75->multiple=50;
        ui->pushButton_76->multiple=50;
        ui->pushButton_77->multiple=50;
        ui->pushButton_78->multiple=50;
        ui->pushButton_79->multiple=50;
        ui->pushButton_80->multiple=50;
        ui->pushButton_81->multiple=50;
        ui->pushButton_82->multiple=50;
        ui->pushButton_83->multiple=50;
        ui->pushButton_84->multiple=50;
        ui->pushButton_85->multiple=50;
        ui->pushButton_86->multiple=50;
        ui->pushButton_87->multiple=50;
        ui->pushButton_88->multiple=50;
        ui->pushButton_89->multiple=50;
        ui->pushButton_90->multiple=50;
        ui->pushButton_91->multiple=50;
        ui->pushButton_92->multiple=50;
        ui->pushButton_93->multiple=50;
        ui->pushButton_94->multiple=50;
        ui->pushButton_95->multiple=50;
        ui->pushButton_96->multiple=50;
        ui->pushButton_97->multiple=50;
        ui->pushButton_98->multiple=50;
        ui->pushButton_99->multiple=50;
        ui->pushButton_100->multiple=50;
        ui->pushButton_101->multiple=50;
        ui->pushButton_102->multiple=50;
        ui->pushButton_103->multiple=50;
        ui->pushButton_104->multiple=50;
        ui->pushButton_105->multiple=50;
        ui->pushButton_106->multiple=50;
        ui->pushButton_107->multiple=50;
        ui->pushButton_108->multiple=50;
        ui->pushButton_109->multiple=50;
        ui->pushButton_110->multiple=50;
        ui->pushButton_111->multiple=50;
        ui->pushButton_112->multiple=50;
        ui->pushButton_113->multiple=50;
        ui->pushButton_114->multiple=50;
        ui->pushButton_115->multiple=50;
        ui->pushButton_116->multiple=50;
        ui->pushButton_117->multiple=50;
        ui->pushButton_118->multiple=50;
        ui->pushButton_119->multiple=50;
        ui->pushButton_120->multiple=50;
        ui->pushButton_121->multiple=50;
        ui->pushButton_122->multiple=50;
        ui->pushButton_123->multiple=50;
        ui->pushButton_124->multiple=50;
        ui->pushButton_125->multiple=50;
        ui->pushButton_126->multiple=50;
        ui->pushButton_127->multiple=50;
        ui->pushButton_128->multiple=50;
        ui->pushButton_129->multiple=50;
        ui->pushButton_130->multiple=50;
        ui->pushButton_131->multiple=50;
        ui->pushButton_132->multiple=50;
        ui->pushButton_133->multiple=50;
        ui->pushButton_134->multiple=50;
        ui->pushButton_135->multiple=50;
        ui->pushButton_136->multiple=50;
        ui->pushButton_137->multiple=50;
        ui->pushButton_138->multiple=50;
        ui->pushButton_139->multiple=50;
        ui->pushButton_140->multiple=50;
        ui->pushButton_141->multiple=50;
        ui->pushButton_142->multiple=50;
        ui->pushButton_143->multiple=50;
        ui->pushButton_144->multiple=50;
    }
    else if(arg1=="10")
    {
        ui->pushButton->multiple=10;
        ui->pushButton_2->multiple=10;
        ui->pushButton_3->multiple=10;
        ui->pushButton_4->multiple=10;
        ui->pushButton_5->multiple=10;
        ui->pushButton_6->multiple=10;
        ui->pushButton_7->multiple=10;
        ui->pushButton_8->multiple=10;
        ui->pushButton_9->multiple=10;
        ui->pushButton_10->multiple=10;
        ui->pushButton_11->multiple=10;
        ui->pushButton_12->multiple=10;
        ui->pushButton_13->multiple=10;
        ui->pushButton_14->multiple=10;
        ui->pushButton_15->multiple=10;
        ui->pushButton_16->multiple=10;
        ui->pushButton_17->multiple=10;
        ui->pushButton_18->multiple=10;
        ui->pushButton_19->multiple=10;
        ui->pushButton_20->multiple=10;
        ui->pushButton_21->multiple=10;
        ui->pushButton_22->multiple=10;
        ui->pushButton_23->multiple=10;
        ui->pushButton_24->multiple=10;
        ui->pushButton_25->multiple=10;
        ui->pushButton_26->multiple=10;
        ui->pushButton_27->multiple=10;
        ui->pushButton_28->multiple=10;
        ui->pushButton_29->multiple=10;
        ui->pushButton_30->multiple=10;
        ui->pushButton_31->multiple=10;
        ui->pushButton_32->multiple=10;
        ui->pushButton_33->multiple=10;
        ui->pushButton_34->multiple=10;
        ui->pushButton_35->multiple=10;
        ui->pushButton_36->multiple=10;
        ui->pushButton_37->multiple=10;
        ui->pushButton_38->multiple=10;
        ui->pushButton_39->multiple=10;
        ui->pushButton_40->multiple=10;
        ui->pushButton_41->multiple=10;
        ui->pushButton_42->multiple=10;
        ui->pushButton_43->multiple=10;
        ui->pushButton_44->multiple=10;
        ui->pushButton_45->multiple=10;
        ui->pushButton_46->multiple=10;
        ui->pushButton_47->multiple=10;
        ui->pushButton_48->multiple=10;
        ui->pushButton_49->multiple=10;
        ui->pushButton_50->multiple=10;
        ui->pushButton_51->multiple=10;
        ui->pushButton_52->multiple=10;
        ui->pushButton_53->multiple=10;
        ui->pushButton_54->multiple=10;
        ui->pushButton_55->multiple=10;
        ui->pushButton_56->multiple=10;
        ui->pushButton_57->multiple=10;
        ui->pushButton_58->multiple=10;
        ui->pushButton_59->multiple=10;
        ui->pushButton_60->multiple=10;
        ui->pushButton_61->multiple=10;
        ui->pushButton_62->multiple=10;
        ui->pushButton_63->multiple=10;
        ui->pushButton_64->multiple=10;
        ui->pushButton_65->multiple=10;
        ui->pushButton_66->multiple=10;
        ui->pushButton_67->multiple=10;
        ui->pushButton_68->multiple=10;
        ui->pushButton_69->multiple=10;
        ui->pushButton_70->multiple=10;
        ui->pushButton_71->multiple=10;
        ui->pushButton_72->multiple=10;
        ui->pushButton_73->multiple=10;
        ui->pushButton_74->multiple=10;
        ui->pushButton_75->multiple=10;
        ui->pushButton_76->multiple=10;
        ui->pushButton_77->multiple=10;
        ui->pushButton_78->multiple=10;
        ui->pushButton_79->multiple=10;
        ui->pushButton_80->multiple=10;
        ui->pushButton_81->multiple=10;
        ui->pushButton_82->multiple=10;
        ui->pushButton_83->multiple=10;
        ui->pushButton_84->multiple=10;
        ui->pushButton_85->multiple=10;
        ui->pushButton_86->multiple=10;
        ui->pushButton_87->multiple=10;
        ui->pushButton_88->multiple=10;
        ui->pushButton_89->multiple=10;
        ui->pushButton_90->multiple=10;
        ui->pushButton_91->multiple=10;
        ui->pushButton_92->multiple=10;
        ui->pushButton_93->multiple=10;
        ui->pushButton_94->multiple=10;
        ui->pushButton_95->multiple=10;
        ui->pushButton_96->multiple=10;
        ui->pushButton_97->multiple=10;
        ui->pushButton_98->multiple=10;
        ui->pushButton_99->multiple=10;
        ui->pushButton_100->multiple=10;
        ui->pushButton_101->multiple=10;
        ui->pushButton_102->multiple=10;
        ui->pushButton_103->multiple=10;
        ui->pushButton_104->multiple=10;
        ui->pushButton_105->multiple=10;
        ui->pushButton_106->multiple=10;
        ui->pushButton_107->multiple=10;
        ui->pushButton_108->multiple=10;
        ui->pushButton_109->multiple=10;
        ui->pushButton_110->multiple=10;
        ui->pushButton_111->multiple=10;
        ui->pushButton_112->multiple=10;
        ui->pushButton_113->multiple=10;
        ui->pushButton_114->multiple=10;
        ui->pushButton_115->multiple=10;
        ui->pushButton_116->multiple=10;
        ui->pushButton_117->multiple=10;
        ui->pushButton_118->multiple=10;
        ui->pushButton_119->multiple=10;
        ui->pushButton_120->multiple=10;
        ui->pushButton_121->multiple=10;
        ui->pushButton_122->multiple=10;
        ui->pushButton_123->multiple=10;
        ui->pushButton_124->multiple=10;
        ui->pushButton_125->multiple=10;
        ui->pushButton_126->multiple=10;
        ui->pushButton_127->multiple=10;
        ui->pushButton_128->multiple=10;
        ui->pushButton_129->multiple=10;
        ui->pushButton_130->multiple=10;
        ui->pushButton_131->multiple=10;
        ui->pushButton_132->multiple=10;
        ui->pushButton_133->multiple=10;
        ui->pushButton_134->multiple=10;
        ui->pushButton_135->multiple=10;
        ui->pushButton_136->multiple=10;
        ui->pushButton_137->multiple=10;
        ui->pushButton_138->multiple=10;
        ui->pushButton_139->multiple=10;
        ui->pushButton_140->multiple=10;
        ui->pushButton_141->multiple=10;
        ui->pushButton_142->multiple=10;
        ui->pushButton_143->multiple=10;
        ui->pushButton_144->multiple=10;
    }
    else
    {
        ui->pushButton->multiple=1;
        ui->pushButton_2->multiple=1;
        ui->pushButton_3->multiple=1;
        ui->pushButton_4->multiple=1;
        ui->pushButton_5->multiple=1;
        ui->pushButton_6->multiple=1;
        ui->pushButton_7->multiple=1;
        ui->pushButton_8->multiple=1;
        ui->pushButton_9->multiple=1;
        ui->pushButton_10->multiple=1;
        ui->pushButton_11->multiple=1;
        ui->pushButton_12->multiple=1;
        ui->pushButton_13->multiple=1;
        ui->pushButton_14->multiple=1;
        ui->pushButton_15->multiple=1;
        ui->pushButton_16->multiple=1;
        ui->pushButton_17->multiple=1;
        ui->pushButton_18->multiple=1;
        ui->pushButton_19->multiple=1;
        ui->pushButton_20->multiple=1;
        ui->pushButton_21->multiple=1;
        ui->pushButton_22->multiple=1;
        ui->pushButton_23->multiple=1;
        ui->pushButton_24->multiple=1;
        ui->pushButton_25->multiple=1;
        ui->pushButton_26->multiple=1;
        ui->pushButton_27->multiple=1;
        ui->pushButton_28->multiple=1;
        ui->pushButton_29->multiple=1;
        ui->pushButton_30->multiple=1;
        ui->pushButton_31->multiple=1;
        ui->pushButton_32->multiple=1;
        ui->pushButton_33->multiple=1;
        ui->pushButton_34->multiple=1;
        ui->pushButton_35->multiple=1;
        ui->pushButton_36->multiple=1;
        ui->pushButton_37->multiple=1;
        ui->pushButton_38->multiple=1;
        ui->pushButton_39->multiple=1;
        ui->pushButton_40->multiple=1;
        ui->pushButton_41->multiple=1;
        ui->pushButton_42->multiple=1;
        ui->pushButton_43->multiple=1;
        ui->pushButton_44->multiple=1;
        ui->pushButton_45->multiple=1;
        ui->pushButton_46->multiple=1;
        ui->pushButton_47->multiple=1;
        ui->pushButton_48->multiple=1;
        ui->pushButton_49->multiple=1;
        ui->pushButton_50->multiple=1;
        ui->pushButton_51->multiple=1;
        ui->pushButton_52->multiple=1;
        ui->pushButton_53->multiple=1;
        ui->pushButton_54->multiple=1;
        ui->pushButton_55->multiple=1;
        ui->pushButton_56->multiple=1;
        ui->pushButton_57->multiple=1;
        ui->pushButton_58->multiple=1;
        ui->pushButton_59->multiple=1;
        ui->pushButton_60->multiple=1;
        ui->pushButton_61->multiple=1;
        ui->pushButton_62->multiple=1;
        ui->pushButton_63->multiple=1;
        ui->pushButton_64->multiple=1;
        ui->pushButton_65->multiple=1;
        ui->pushButton_66->multiple=1;
        ui->pushButton_67->multiple=1;
        ui->pushButton_68->multiple=1;
        ui->pushButton_69->multiple=1;
        ui->pushButton_70->multiple=1;
        ui->pushButton_71->multiple=1;
        ui->pushButton_72->multiple=1;
        ui->pushButton_73->multiple=1;
        ui->pushButton_74->multiple=1;
        ui->pushButton_75->multiple=1;
        ui->pushButton_76->multiple=1;
        ui->pushButton_77->multiple=1;
        ui->pushButton_78->multiple=1;
        ui->pushButton_79->multiple=1;
        ui->pushButton_80->multiple=1;
        ui->pushButton_81->multiple=1;
        ui->pushButton_82->multiple=1;
        ui->pushButton_83->multiple=1;
        ui->pushButton_84->multiple=1;
        ui->pushButton_85->multiple=1;
        ui->pushButton_86->multiple=1;
        ui->pushButton_87->multiple=1;
        ui->pushButton_88->multiple=1;
        ui->pushButton_89->multiple=1;
        ui->pushButton_90->multiple=1;
        ui->pushButton_91->multiple=1;
        ui->pushButton_92->multiple=1;
        ui->pushButton_93->multiple=1;
        ui->pushButton_94->multiple=1;
        ui->pushButton_95->multiple=1;
        ui->pushButton_96->multiple=1;
        ui->pushButton_97->multiple=1;
        ui->pushButton_98->multiple=1;
        ui->pushButton_99->multiple=1;
        ui->pushButton_100->multiple=1;
        ui->pushButton_101->multiple=1;
        ui->pushButton_102->multiple=1;
        ui->pushButton_103->multiple=1;
        ui->pushButton_104->multiple=1;
        ui->pushButton_105->multiple=1;
        ui->pushButton_106->multiple=1;
        ui->pushButton_107->multiple=1;
        ui->pushButton_108->multiple=1;
        ui->pushButton_109->multiple=1;
        ui->pushButton_110->multiple=1;
        ui->pushButton_111->multiple=1;
        ui->pushButton_112->multiple=1;
        ui->pushButton_113->multiple=1;
        ui->pushButton_114->multiple=1;
        ui->pushButton_115->multiple=1;
        ui->pushButton_116->multiple=1;
        ui->pushButton_117->multiple=1;
        ui->pushButton_118->multiple=1;
        ui->pushButton_119->multiple=1;
        ui->pushButton_120->multiple=1;
        ui->pushButton_121->multiple=1;
        ui->pushButton_122->multiple=1;
        ui->pushButton_123->multiple=1;
        ui->pushButton_124->multiple=1;
        ui->pushButton_125->multiple=1;
        ui->pushButton_126->multiple=1;
        ui->pushButton_127->multiple=1;
        ui->pushButton_128->multiple=1;
        ui->pushButton_129->multiple=1;
        ui->pushButton_130->multiple=1;
        ui->pushButton_131->multiple=1;
        ui->pushButton_132->multiple=1;
        ui->pushButton_133->multiple=1;
        ui->pushButton_134->multiple=1;
        ui->pushButton_135->multiple=1;
        ui->pushButton_136->multiple=1;
        ui->pushButton_137->multiple=1;
        ui->pushButton_138->multiple=1;
        ui->pushButton_139->multiple=1;
        ui->pushButton_140->multiple=1;
        ui->pushButton_141->multiple=1;
        ui->pushButton_142->multiple=1;
        ui->pushButton_143->multiple=1;
        ui->pushButton_144->multiple=1;
    }
}

void DlgMask::on_pushButton_145_clicked() //����
{
    //Qt��ʹ��QSettings���дini�ļ�
    //QSettings���캯���ĵ�һ��������ini�ļ���·��,�ڶ���������ʾ���ini�ļ�,��������������ȱʡ
    QSettings *configIniWrite = new QSettings("maskdata.ini", QSettings::IniFormat);
    //��ini�ļ���д������,setValue���������������Ǽ�ֵ��
    //��ini�ļ��ĵ�һ����д������,ip���µĵ�һ������
    configIniWrite->setValue("/mask/one", ui->pushButton->text());
    configIniWrite->setValue("mask/two", ui->pushButton_2->text());
    configIniWrite->setValue("mask/three", ui->pushButton_3->text());
    configIniWrite->setValue("mask/four", ui->pushButton_4->text());
    configIniWrite->setValue("mask/five", ui->pushButton_5->text());
    configIniWrite->setValue("mask/six", ui->pushButton_6->text());
    configIniWrite->setValue("mask/seven", ui->pushButton_7->text());
    configIniWrite->setValue("mask/eight", ui->pushButton_8->text());
    configIniWrite->setValue("mask/nine", ui->pushButton_9->text());

    configIniWrite->setValue("mask/onezero", ui->pushButton_10->text());
    configIniWrite->setValue("mask/oneone", ui->pushButton_11->text());
    configIniWrite->setValue("mask/onetwo", ui->pushButton_12->text());
    configIniWrite->setValue("mask/onethree", ui->pushButton_13->text());
    configIniWrite->setValue("mask/onefour", ui->pushButton_14->text());
    configIniWrite->setValue("mask/onefive", ui->pushButton_15->text());
    configIniWrite->setValue("mask/onesix", ui->pushButton_16->text());
    configIniWrite->setValue("mask/oneseven", ui->pushButton_17->text());
    configIniWrite->setValue("mask/oneeight", ui->pushButton_18->text());
    configIniWrite->setValue("mask/onenine", ui->pushButton_19->text());

    configIniWrite->setValue("mask/twozero", ui->pushButton_20->text());
    configIniWrite->setValue("mask/twoone", ui->pushButton_21->text());
    configIniWrite->setValue("mask/twotwo", ui->pushButton_22->text());
    configIniWrite->setValue("mask/twothree", ui->pushButton_23->text());
    configIniWrite->setValue("mask/twofour", ui->pushButton_24->text());
    configIniWrite->setValue("mask/twofive", ui->pushButton_25->text());
    configIniWrite->setValue("mask/twosix", ui->pushButton_26->text());
    configIniWrite->setValue("mask/twoseven", ui->pushButton_27->text());
    configIniWrite->setValue("mask/twoeight", ui->pushButton_28->text());
    configIniWrite->setValue("mask/twonine", ui->pushButton_29->text());

    configIniWrite->setValue("mask/threezero", ui->pushButton_30->text());
    configIniWrite->setValue("mask/threeone", ui->pushButton_31->text());
    configIniWrite->setValue("mask/threetwo", ui->pushButton_32->text());
    configIniWrite->setValue("mask/threethree", ui->pushButton_33->text());
    configIniWrite->setValue("mask/threefour", ui->pushButton_34->text());
    configIniWrite->setValue("mask/threefive", ui->pushButton_35->text());
    configIniWrite->setValue("mask/threesix", ui->pushButton_36->text());
    configIniWrite->setValue("mask/threeseven", ui->pushButton_37->text());
    configIniWrite->setValue("mask/threeeight", ui->pushButton_38->text());
    configIniWrite->setValue("mask/threenine", ui->pushButton_39->text());

    configIniWrite->setValue("mask/fourzero", ui->pushButton_40->text());
    configIniWrite->setValue("mask/fourone", ui->pushButton_41->text());
    configIniWrite->setValue("mask/fourtwo", ui->pushButton_42->text());
    configIniWrite->setValue("mask/fourthree", ui->pushButton_43->text());
    configIniWrite->setValue("mask/fourfour", ui->pushButton_44->text());
    configIniWrite->setValue("mask/fourfive", ui->pushButton_45->text());
    configIniWrite->setValue("mask/foursix", ui->pushButton_46->text());
    configIniWrite->setValue("mask/fourseven", ui->pushButton_47->text());
    configIniWrite->setValue("mask/foureight", ui->pushButton_48->text());
    configIniWrite->setValue("mask/fournine", ui->pushButton_49->text());

    configIniWrite->setValue("mask/fivezero", ui->pushButton_50->text());
    configIniWrite->setValue("mask/fiveone", ui->pushButton_51->text());
    configIniWrite->setValue("mask/fivetwo", ui->pushButton_52->text());
    configIniWrite->setValue("mask/fivethree", ui->pushButton_53->text());
    configIniWrite->setValue("mask/fivefour", ui->pushButton_54->text());
    configIniWrite->setValue("mask/fivefive", ui->pushButton_55->text());
    configIniWrite->setValue("mask/fivesix", ui->pushButton_56->text());
    configIniWrite->setValue("mask/fiveseven", ui->pushButton_57->text());
    configIniWrite->setValue("mask/fiveeight", ui->pushButton_58->text());
    configIniWrite->setValue("mask/fivenine", ui->pushButton_59->text());

    configIniWrite->setValue("mask/sixzero", ui->pushButton_60->text());
    configIniWrite->setValue("mask/sixone", ui->pushButton_61->text());
    configIniWrite->setValue("mask/sixtwo", ui->pushButton_62->text());
    configIniWrite->setValue("mask/sixthree", ui->pushButton_63->text());
    configIniWrite->setValue("mask/sixfour", ui->pushButton_64->text());
    configIniWrite->setValue("mask/sixfive", ui->pushButton_65->text());
    configIniWrite->setValue("mask/sixsix", ui->pushButton_66->text());
    configIniWrite->setValue("mask/sixseven", ui->pushButton_67->text());
    configIniWrite->setValue("mask/sixeight", ui->pushButton_68->text());
    configIniWrite->setValue("mask/sixnine", ui->pushButton_69->text());

    configIniWrite->setValue("mask/sevenzero", ui->pushButton_70->text());
    configIniWrite->setValue("mask/sevenone", ui->pushButton_71->text());
    configIniWrite->setValue("mask/seventwo", ui->pushButton_72->text());
    configIniWrite->setValue("mask/seventhree", ui->pushButton_73->text());
    configIniWrite->setValue("mask/sevenfour", ui->pushButton_74->text());
    configIniWrite->setValue("mask/sevenfive", ui->pushButton_75->text());
    configIniWrite->setValue("mask/sevensix", ui->pushButton_76->text());
    configIniWrite->setValue("mask/sevenseven", ui->pushButton_77->text());
    configIniWrite->setValue("mask/seveneight", ui->pushButton_78->text());
    configIniWrite->setValue("mask/sevennine", ui->pushButton_79->text());

    configIniWrite->setValue("mask/eightzero", ui->pushButton_80->text());
    configIniWrite->setValue("mask/eightone", ui->pushButton_81->text());
    configIniWrite->setValue("mask/eighttwo", ui->pushButton_82->text());
    configIniWrite->setValue("mask/eightthree", ui->pushButton_83->text());
    configIniWrite->setValue("mask/eightfour", ui->pushButton_84->text());
    configIniWrite->setValue("mask/eightfive", ui->pushButton_85->text());
    configIniWrite->setValue("mask/eightsix", ui->pushButton_86->text());
    configIniWrite->setValue("mask/eightseven", ui->pushButton_87->text());
    configIniWrite->setValue("mask/eighteight", ui->pushButton_88->text());
    configIniWrite->setValue("mask/eightnine", ui->pushButton_89->text());

    configIniWrite->setValue("mask/ninezero", ui->pushButton_90->text());
    configIniWrite->setValue("mask/nineone", ui->pushButton_91->text());
    configIniWrite->setValue("mask/ninetwo", ui->pushButton_92->text());
    configIniWrite->setValue("mask/ninethree", ui->pushButton_93->text());
    configIniWrite->setValue("mask/ninefour", ui->pushButton_94->text());
    configIniWrite->setValue("mask/ninefive", ui->pushButton_95->text());
    configIniWrite->setValue("mask/ninesix", ui->pushButton_96->text());
    configIniWrite->setValue("mask/nineseven", ui->pushButton_97->text());
    configIniWrite->setValue("mask/nineeight", ui->pushButton_98->text());
    configIniWrite->setValue("mask/ninenine", ui->pushButton_99->text());

   configIniWrite->setValue("mask/onezerozero", ui->pushButton_100->text());
   configIniWrite->setValue("mask/onezeroone", ui->pushButton_101->text());
    configIniWrite->setValue("mask/onezerotwo", ui->pushButton_102->text());
    configIniWrite->setValue("mask/onezerothree", ui->pushButton_103->text());
    configIniWrite->setValue("mask/onezerofour", ui->pushButton_104->text());
    configIniWrite->setValue("mask/onezerofive", ui->pushButton_105->text());
    configIniWrite->setValue("mask/onezerosix", ui->pushButton_106->text());
    configIniWrite->setValue("mask/onezeroseven", ui->pushButton_107->text());
    configIniWrite->setValue("mask/onezeroeight", ui->pushButton_108->text());
    configIniWrite->setValue("mask/onezeronine", ui->pushButton_109->text());

    configIniWrite->setValue("mask/oneonezero", ui->pushButton_110->text());
    configIniWrite->setValue("mask/oneoneone", ui->pushButton_111->text());
    configIniWrite->setValue("mask/oneonetwo", ui->pushButton_112->text());
    configIniWrite->setValue("mask/oneonethree", ui->pushButton_113->text());
    configIniWrite->setValue("mask/oneonefour", ui->pushButton_114->text());
    configIniWrite->setValue("mask/oneonefive", ui->pushButton_115->text());
    configIniWrite->setValue("mask/oneonesix", ui->pushButton_116->text());
    configIniWrite->setValue("mask/oneoneseven", ui->pushButton_117->text());
    configIniWrite->setValue("mask/oneoneeight", ui->pushButton_118->text());
    configIniWrite->setValue("mask/oneonenine", ui->pushButton_119->text());

    configIniWrite->setValue("mask/onetwozero", ui->pushButton_120->text());
    configIniWrite->setValue("mask/onetwoone", ui->pushButton_121->text());
    configIniWrite->setValue("mask/onetwotwo", ui->pushButton_122->text());
    configIniWrite->setValue("mask/onetwothree", ui->pushButton_123->text());
    configIniWrite->setValue("mask/onetwofour", ui->pushButton_124->text());
    configIniWrite->setValue("mask/onetwofive", ui->pushButton_125->text());
    configIniWrite->setValue("mask/onetwosix", ui->pushButton_126->text());
    configIniWrite->setValue("mask/onetwoseven", ui->pushButton_127->text());
    configIniWrite->setValue("mask/onetwoeight", ui->pushButton_128->text());
    configIniWrite->setValue("mask/onetwonine", ui->pushButton_129->text());

    configIniWrite->setValue("mask/onethreezero", ui->pushButton_130->text());
    configIniWrite->setValue("mask/onethreeone", ui->pushButton_131->text());
    configIniWrite->setValue("mask/onethreetwo", ui->pushButton_132->text());
    configIniWrite->setValue("mask/onethreethree", ui->pushButton_133->text());
    configIniWrite->setValue("mask/onethreefour", ui->pushButton_134->text());
    configIniWrite->setValue("mask/onethreefive", ui->pushButton_135->text());
    configIniWrite->setValue("mask/onethreesix", ui->pushButton_136->text());
    configIniWrite->setValue("mask/onethreeseven", ui->pushButton_137->text());
    configIniWrite->setValue("mask/onethreeeight", ui->pushButton_138->text());
    configIniWrite->setValue("mask/onethreenine", ui->pushButton_139->text());

    configIniWrite->setValue("mask/onefourzero", ui->pushButton_140->text());
    configIniWrite->setValue("mask/onefourone", ui->pushButton_141->text());
    configIniWrite->setValue("mask/onefourtwo", ui->pushButton_142->text());
    configIniWrite->setValue("mask/onefourthree", ui->pushButton_143->text());
    configIniWrite->setValue("mask/onefourfour", ui->pushButton_144->text());


    //д����ɺ�ɾ��ָ��
    delete configIniWrite;
}

void DlgMask::creategeneralMask()
{
    mMask=QImage(1920,1080,QImage::Format_ARGB32_Premultiplied);
    mMask.fill(qRgba(0,0,0,0));
////////////****************************************///////////////////
    QSettings *configIniRead = new QSettings("maskdata.ini", QSettings::IniFormat);
    //����ȡ����ini�ļ�������QString�У���ȡֵ��Ȼ��ͨ��toString()����ת����QString����
    ui->pushButton->setText(configIniRead->value("/mask/one").toString());
    ui->pushButton_2->setText(configIniRead->value("/mask/two").toString());
    ui->pushButton_3->setText(configIniRead->value("/mask/three").toString());
    ui->pushButton_4->setText(configIniRead->value("/mask/four").toString());
    ui->pushButton_5->setText(configIniRead->value("/mask/five").toString());
    ui->pushButton_6->setText(configIniRead->value("/mask/six").toString());
    ui->pushButton_7->setText(configIniRead->value("/mask/seven").toString());
    ui->pushButton_8->setText(configIniRead->value("/mask/eight").toString());
    ui->pushButton_9->setText(configIniRead->value("/mask/nine").toString());
    ui->pushButton_10->setText(configIniRead->value("/mask/onezero").toString());
    ui->pushButton_11->setText(configIniRead->value("/mask/oneone").toString());
    ui->pushButton_12->setText(configIniRead->value("/mask/onetwo").toString());
    ui->pushButton_13->setText(configIniRead->value("/mask/onethree").toString());
    ui->pushButton_14->setText(configIniRead->value("/mask/onefour").toString());
    ui->pushButton_15->setText(configIniRead->value("/mask/onefive").toString());
    ui->pushButton_16->setText(configIniRead->value("/mask/onesix").toString());
    ui->pushButton_17->setText(configIniRead->value("/mask/oneseven").toString());
    ui->pushButton_18->setText(configIniRead->value("/mask/oneeight").toString());
    ui->pushButton_19->setText(configIniRead->value("/mask/onenine").toString());
    ui->pushButton_20->setText(configIniRead->value("/mask/twozero").toString());
    ui->pushButton_21->setText(configIniRead->value("/mask/twoone").toString());
    ui->pushButton_22->setText(configIniRead->value("/mask/twotwo").toString());
    ui->pushButton_23->setText(configIniRead->value("/mask/twothree").toString());
    ui->pushButton_24->setText(configIniRead->value("/mask/twofour").toString());
    ui->pushButton_25->setText(configIniRead->value("/mask/twofive").toString());
    ui->pushButton_26->setText(configIniRead->value("/mask/twosix").toString());
    ui->pushButton_27->setText(configIniRead->value("/mask/twoseven").toString());
    ui->pushButton_28->setText(configIniRead->value("/mask/twoeight").toString());
    ui->pushButton_29->setText(configIniRead->value("/mask/twonine").toString());
    ui->pushButton_30->setText(configIniRead->value("/mask/threezero").toString());
    ui->pushButton_31->setText(configIniRead->value("/mask/threeone").toString());
    ui->pushButton_32->setText(configIniRead->value("/mask/threetwo").toString());
    ui->pushButton_33->setText(configIniRead->value("/mask/threethree").toString());
    ui->pushButton_34->setText(configIniRead->value("/mask/threefour").toString());
    ui->pushButton_35->setText(configIniRead->value("/mask/threefive").toString());
    ui->pushButton_36->setText(configIniRead->value("/mask/threesix").toString());
    ui->pushButton_37->setText(configIniRead->value("/mask/threeseven").toString());
    ui->pushButton_38->setText(configIniRead->value("/mask/threeeight").toString());
    ui->pushButton_39->setText(configIniRead->value("/mask/threenine").toString());
    ui->pushButton_40->setText(configIniRead->value("/mask/fourzero").toString());
    ui->pushButton_41->setText(configIniRead->value("/mask/fourone").toString());
    ui->pushButton_42->setText(configIniRead->value("/mask/fourtwo").toString());
    ui->pushButton_43->setText(configIniRead->value("/mask/fourthree").toString());
    ui->pushButton_44->setText(configIniRead->value("/mask/fourfour").toString());
    ui->pushButton_45->setText(configIniRead->value("/mask/fourfive").toString());
    ui->pushButton_46->setText(configIniRead->value("/mask/foursix").toString());
    ui->pushButton_47->setText(configIniRead->value("/mask/fourseven").toString());
    ui->pushButton_48->setText(configIniRead->value("/mask/foureight").toString());
    ui->pushButton_49->setText(configIniRead->value("/mask/fournine").toString());
    ui->pushButton_50->setText(configIniRead->value("/mask/fivezero").toString());
    ui->pushButton_51->setText(configIniRead->value("/mask/fiveone").toString());
    ui->pushButton_52->setText(configIniRead->value("/mask/fivetwo").toString());
    ui->pushButton_53->setText(configIniRead->value("/mask/fivethree").toString());
    ui->pushButton_54->setText(configIniRead->value("/mask/fivefour").toString());
    ui->pushButton_55->setText(configIniRead->value("/mask/fivefive").toString());
    ui->pushButton_56->setText(configIniRead->value("/mask/fivesix").toString());
    ui->pushButton_57->setText(configIniRead->value("/mask/fiveseven").toString());
    ui->pushButton_58->setText(configIniRead->value("/mask/fiveeight").toString());
    ui->pushButton_59->setText(configIniRead->value("/mask/fivenine").toString());
    ui->pushButton_60->setText(configIniRead->value("/mask/sixzero").toString());
    ui->pushButton_61->setText(configIniRead->value("/mask/sixone").toString());
    ui->pushButton_62->setText(configIniRead->value("/mask/sixtwo").toString());
    ui->pushButton_63->setText(configIniRead->value("/mask/sixthree").toString());
    ui->pushButton_64->setText(configIniRead->value("/mask/sixfour").toString());
    ui->pushButton_65->setText(configIniRead->value("/mask/sixfive").toString());
    ui->pushButton_66->setText(configIniRead->value("/mask/sixsix").toString());
    ui->pushButton_67->setText(configIniRead->value("/mask/sixseven").toString());
    ui->pushButton_68->setText(configIniRead->value("/mask/sixeight").toString());
    ui->pushButton_69->setText(configIniRead->value("/mask/sixnine").toString());
    ui->pushButton_70->setText(configIniRead->value("/mask/sevenzero").toString());
    ui->pushButton_71->setText(configIniRead->value("/mask/sevenone").toString());
    ui->pushButton_72->setText(configIniRead->value("/mask/seventwo").toString());
    ui->pushButton_73->setText(configIniRead->value("/mask/seventhree").toString());
    ui->pushButton_74->setText(configIniRead->value("/mask/sevenfour").toString());
    ui->pushButton_75->setText(configIniRead->value("/mask/sevenfive").toString());
    ui->pushButton_76->setText(configIniRead->value("/mask/sevensix").toString());
    ui->pushButton_77->setText(configIniRead->value("/mask/sevenseven").toString());
    ui->pushButton_78->setText(configIniRead->value("/mask/seveneight").toString());
    ui->pushButton_79->setText(configIniRead->value("/mask/sevennine").toString());
    ui->pushButton_80->setText(configIniRead->value("/mask/eightzero").toString());
    ui->pushButton_81->setText(configIniRead->value("/mask/eightone").toString());
    ui->pushButton_82->setText(configIniRead->value("/mask/eighttwo").toString());
    ui->pushButton_83->setText(configIniRead->value("/mask/eightthree").toString());
    ui->pushButton_84->setText(configIniRead->value("/mask/eightfour").toString());
    ui->pushButton_85->setText(configIniRead->value("/mask/eightfive").toString());
    ui->pushButton_86->setText(configIniRead->value("/mask/eightsix").toString());
    ui->pushButton_87->setText(configIniRead->value("/mask/eightseven").toString());
    ui->pushButton_88->setText(configIniRead->value("/mask/eighteight").toString());
    ui->pushButton_89->setText(configIniRead->value("/mask/eightnine").toString());
    ui->pushButton_90->setText(configIniRead->value("/mask/ninezero").toString());
    ui->pushButton_91->setText(configIniRead->value("/mask/nineone").toString());
    ui->pushButton_92->setText(configIniRead->value("/mask/ninetwo").toString());
    ui->pushButton_93->setText(configIniRead->value("/mask/ninethree").toString());
    ui->pushButton_94->setText(configIniRead->value("/mask/ninefour").toString());
    ui->pushButton_95->setText(configIniRead->value("/mask/ninefive").toString());
    ui->pushButton_96->setText(configIniRead->value("/mask/ninesix").toString());
    ui->pushButton_97->setText(configIniRead->value("/mask/nineseven").toString());
    ui->pushButton_98->setText(configIniRead->value("/mask/nineeight").toString());
    ui->pushButton_99->setText(configIniRead->value("/mask/ninenine").toString());
    ui->pushButton_100->setText(configIniRead->value("/mask/onezerozero").toString());
    ui->pushButton_101->setText(configIniRead->value("/mask/onezeroone").toString());
    ui->pushButton_102->setText(configIniRead->value("/mask/onezerotwo").toString());
    ui->pushButton_103->setText(configIniRead->value("/mask/onezerothree").toString());
    ui->pushButton_104->setText(configIniRead->value("/mask/onezerofour").toString());
    ui->pushButton_105->setText(configIniRead->value("/mask/onezerofive").toString());
    ui->pushButton_106->setText(configIniRead->value("/mask/onezerosix").toString());
    ui->pushButton_107->setText(configIniRead->value("/mask/onezeroseven").toString());
    ui->pushButton_108->setText(configIniRead->value("/mask/onezeroeight").toString());
    ui->pushButton_109->setText(configIniRead->value("/mask/onezeronine").toString());
    ui->pushButton_110->setText(configIniRead->value("/mask/oneonezero").toString());
    ui->pushButton_111->setText(configIniRead->value("/mask/oneoneone").toString());
    ui->pushButton_112->setText(configIniRead->value("/mask/oneonetwo").toString());
    ui->pushButton_113->setText(configIniRead->value("/mask/oneonethree").toString());
    ui->pushButton_114->setText(configIniRead->value("/mask/oneonefour").toString());
    ui->pushButton_115->setText(configIniRead->value("/mask/oneonefive").toString());
    ui->pushButton_116->setText(configIniRead->value("/mask/oneonesix").toString());
    ui->pushButton_117->setText(configIniRead->value("/mask/oneoneseven").toString());
    ui->pushButton_118->setText(configIniRead->value("/mask/oneoneeight").toString());
    ui->pushButton_119->setText(configIniRead->value("/mask/oneonenine").toString());
    ui->pushButton_120->setText(configIniRead->value("/mask/onetwozero").toString());
    ui->pushButton_121->setText(configIniRead->value("/mask/onetwoone").toString());
    ui->pushButton_122->setText(configIniRead->value("/mask/onetwotwo").toString());
    ui->pushButton_123->setText(configIniRead->value("/mask/onetwothree").toString());
    ui->pushButton_124->setText(configIniRead->value("/mask/onetwofour").toString());
    ui->pushButton_125->setText(configIniRead->value("/mask/onetwofive").toString());
    ui->pushButton_126->setText(configIniRead->value("/mask/onetwosix").toString());
    ui->pushButton_127->setText(configIniRead->value("/mask/onetwoseven").toString());
    ui->pushButton_128->setText(configIniRead->value("/mask/onetwoeight").toString());
    ui->pushButton_129->setText(configIniRead->value("/mask/onetwonine").toString());
    ui->pushButton_130->setText(configIniRead->value("/mask/onethreezero").toString());
    ui->pushButton_131->setText(configIniRead->value("/mask/onethreeone").toString());
    ui->pushButton_132->setText(configIniRead->value("/mask/onethreetwo").toString());
    ui->pushButton_133->setText(configIniRead->value("/mask/onethreethree").toString());
    ui->pushButton_134->setText(configIniRead->value("/mask/onethreefour").toString());
    ui->pushButton_135->setText(configIniRead->value("/mask/onethreefive").toString());
    ui->pushButton_136->setText(configIniRead->value("/mask/onethreesix").toString());
    ui->pushButton_137->setText(configIniRead->value("/mask/onethreeseven").toString());
    ui->pushButton_138->setText(configIniRead->value("/mask/onethreeeight").toString());
    ui->pushButton_139->setText(configIniRead->value("/mask/onethreenine").toString());
    ui->pushButton_140->setText(configIniRead->value("/mask/onefourzero").toString());
    ui->pushButton_141->setText(configIniRead->value("/mask/onefourone").toString());
    ui->pushButton_142->setText(configIniRead->value("/mask/onefourtwo").toString());
    ui->pushButton_143->setText(configIniRead->value("/mask/onefourthree").toString());
    ui->pushButton_144->setText(configIniRead->value("/mask/onefourfour").toString());
    //��������ɺ�ɾ��ָ��
    delete configIniRead;
////////****************************************************/////////
    for (quint32 y = 0; y < 120; ++y)///////////////1
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 0; x < 120; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton->text().toInt(),ui->pushButton->text().toInt(),ui->pushButton->text().toInt(),255);
            }
    }

    for (quint32 y = 0; y < 120; ++y)///////////////2
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 120; x < 240; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_2->text().toInt(),ui->pushButton_2->text().toInt(),ui->pushButton_2->text().toInt(),255);
            }
    }
    for (quint32 y = 0; y < 120; ++y)///////////////3
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 240; x < 360; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_3->text().toInt(),ui->pushButton_3->text().toInt(),ui->pushButton_3->text().toInt(),255);
            }
    }

    for (quint32 y = 0; y < 120; ++y)///////////////4
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 360; x < 480; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_4->text().toInt(),ui->pushButton_4->text().toInt(),ui->pushButton_4->text().toInt(),255);
            }
    }

    for (quint32 y = 0; y < 120; ++y)///////////////5
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 480; x < 600; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_5->text().toInt(),ui->pushButton_5->text().toInt(),ui->pushButton_5->text().toInt(),255);
            }
    }

    for (quint32 y = 0; y < 120; ++y)///////////////6
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 600; x < 720; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_6->text().toInt(),ui->pushButton_6->text().toInt(),ui->pushButton_6->text().toInt(),255);
            }
    }

    for (quint32 y = 0; y < 120; ++y)///////////////7
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 720; x < 840; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_7->text().toInt(),ui->pushButton_7->text().toInt(),ui->pushButton_7->text().toInt(),255);
            }
    }

    for (quint32 y = 0; y < 120; ++y)///////////////8
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 840; x < 960; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_8->text().toInt(),ui->pushButton_8->text().toInt(),ui->pushButton_8->text().toInt(),255);
            }
    }

    for (quint32 y = 0; y < 120; ++y)///////////////9
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 960; x < 1080; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_9->text().toInt(),ui->pushButton_9->text().toInt(),ui->pushButton_9->text().toInt(),255);
            }
    }

    for (quint32 y = 0; y < 120; ++y)///////////////10
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1080; x < 1200; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_10->text().toInt(),ui->pushButton_10->text().toInt(),ui->pushButton_10->text().toInt(),255);
            }
    }

    for (quint32 y = 0; y < 120; ++y)///////////////11
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1200; x < 1320; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_11->text().toInt(),ui->pushButton_11->text().toInt(),ui->pushButton_11->text().toInt(),255);
            }
    }

    for (quint32 y = 0; y < 120; ++y)///////////////12
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1320; x < 1440; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_12->text().toInt(),ui->pushButton_12->text().toInt(),ui->pushButton_12->text().toInt(),255);
            }
    }

    for (quint32 y = 0; y < 120; ++y)///////////////13
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1440; x < 1560; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_13->text().toInt(),ui->pushButton_13->text().toInt(),ui->pushButton_13->text().toInt(),255);
            }
    }
    for (quint32 y = 0; y < 120; ++y)///////////////14
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1560; x < 1680; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_14->text().toInt(),ui->pushButton_14->text().toInt(),ui->pushButton_14->text().toInt(),255);
            }
    }

    for (quint32 y = 0; y < 120; ++y)///////////////15
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1680; x < 1800; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_15->text().toInt(),ui->pushButton_15->text().toInt(),ui->pushButton_15->text().toInt(),255);
            }
    }

    for (quint32 y = 0; y < 120; ++y)///////////////16
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1800; x < 1920; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_16->text().toInt(),ui->pushButton_16->text().toInt(),ui->pushButton_16->text().toInt(),255);
            }
    }
/////**********************************************************/////
    for (quint32 y = 120; y < 240; ++y)///////////////17
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 0; x < 120; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_17->text().toInt(),ui->pushButton_17->text().toInt(),ui->pushButton_17->text().toInt(),255);
            }
    }

    for (quint32 y = 120; y < 240; ++y)///////////////18
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 120; x < 240; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_18->text().toInt(),ui->pushButton_18->text().toInt(),ui->pushButton_18->text().toInt(),255);
            }
    }
    for (quint32 y = 120; y < 240; ++y)///////////////19
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 240; x < 360; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_19->text().toInt(),ui->pushButton_19->text().toInt(),ui->pushButton_19->text().toInt(),255);
            }
    }

    for (quint32 y = 120; y < 240; ++y)///////////////20
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 360; x < 480; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_20->text().toInt(),ui->pushButton_20->text().toInt(),ui->pushButton_20->text().toInt(),255);
            }
    }

    for (quint32 y = 120; y < 240; ++y)///////////////21
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 480; x < 600; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_21->text().toInt(),ui->pushButton_21->text().toInt(),ui->pushButton_21->text().toInt(),255);
            }
    }

    for (quint32 y = 120; y < 240; ++y)///////////////22
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 600; x < 720; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_22->text().toInt(),ui->pushButton_22->text().toInt(),ui->pushButton_22->text().toInt(),255);
            }
    }

    for (quint32 y = 120; y < 240; ++y)///////////////23
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 720; x < 840; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_23->text().toInt(),ui->pushButton_23->text().toInt(),ui->pushButton_23->text().toInt(),255);
            }
    }

    for (quint32 y = 120; y < 240; ++y)///////////////24
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 840; x < 960; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_24->text().toInt(),ui->pushButton_24->text().toInt(),ui->pushButton_24->text().toInt(),255);
            }
    }

   for (quint32 y = 120; y < 240; ++y)///////////////25
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 960; x < 1080; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_25->text().toInt(),ui->pushButton_25->text().toInt(),ui->pushButton_25->text().toInt(),255);
            }
    }

    for (quint32 y = 120; y < 240; ++y)///////////////26
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1080; x < 1200; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_26->text().toInt(),ui->pushButton_26->text().toInt(),ui->pushButton_26->text().toInt(),255);
            }
    }

    for (quint32 y = 120; y < 240; ++y)///////////////27
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1200; x < 1320; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_27->text().toInt(),ui->pushButton_27->text().toInt(),ui->pushButton_27->text().toInt(),255);
            }
    }

    for (quint32 y = 120; y < 240; ++y)///////////////28
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1320; x < 1440; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_28->text().toInt(),ui->pushButton_28->text().toInt(),ui->pushButton_28->text().toInt(),255);
            }
    }

    for (quint32 y = 120; y < 240; ++y)///////////////29
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1440; x < 1560; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_29->text().toInt(),ui->pushButton_29->text().toInt(),ui->pushButton_29->text().toInt(),255);
            }
    }
    for (quint32 y = 120; y < 240; ++y)///////////////30
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1560; x < 1680; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_30->text().toInt(),ui->pushButton_30->text().toInt(),ui->pushButton_30->text().toInt(),255);
            }
    }

    for (quint32 y = 120; y < 240; ++y)///////////////31
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1680; x < 1800; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_31->text().toInt(),ui->pushButton_31->text().toInt(),ui->pushButton_31->text().toInt(),255);
            }
    }

    for (quint32 y = 120; y < 240; ++y)///////////////32
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1800; x < 1920; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_32->text().toInt(),ui->pushButton_32->text().toInt(),ui->pushButton_32->text().toInt(),255);
            }
    }
//////////************************************************///////////////////
    for (quint32 y = 240; y < 360; ++y)///////////////33
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 0; x < 120; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_33->text().toInt(),ui->pushButton_33->text().toInt(),ui->pushButton_33->text().toInt(),255);
            }
    }

    for (quint32 y = 240; y < 360; ++y)///////////////34
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 120; x < 240; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_34->text().toInt(),ui->pushButton_34->text().toInt(),ui->pushButton_34->text().toInt(),255);
            }
    }
    for (quint32 y = 240; y < 360; ++y)///////////////35
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 240; x < 360; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_35->text().toInt(),ui->pushButton_35->text().toInt(),ui->pushButton_35->text().toInt(),255);
            }
    }

    for (quint32 y = 240; y < 360; ++y)///////////////36
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 360; x < 480; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_36->text().toInt(),ui->pushButton_36->text().toInt(),ui->pushButton_36->text().toInt(),255);
            }
    }

    for (quint32 y = 240; y < 360; ++y)///////////////37
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 480; x < 600; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_37->text().toInt(),ui->pushButton_37->text().toInt(),ui->pushButton_37->text().toInt(),255);
            }
    }

    for (quint32 y = 240; y < 360; ++y)///////////////38
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 600; x < 720; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_38->text().toInt(),ui->pushButton_38->text().toInt(),ui->pushButton_38->text().toInt(),255);
            }
    }

    for (quint32 y = 240; y < 360; ++y)///////////////39
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 720; x < 840; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_39->text().toInt(),ui->pushButton_39->text().toInt(),ui->pushButton_39->text().toInt(),255);
            }
    }

    for (quint32 y = 240; y < 360; ++y)///////////////40
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 840; x < 960; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_40->text().toInt(),ui->pushButton_40->text().toInt(),ui->pushButton_40->text().toInt(),255);
            }
    }

   for (quint32 y = 240; y < 360; ++y)///////////////41
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 960; x < 1080; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_41->text().toInt(),ui->pushButton_41->text().toInt(),ui->pushButton_41->text().toInt(),255);
            }
    }

    for (quint32 y = 240; y < 360; ++y)///////////////42
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1080; x < 1200; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_42->text().toInt(),ui->pushButton_42->text().toInt(),ui->pushButton_42->text().toInt(),255);
            }
    }

    for (quint32 y = 240; y < 360; ++y)///////////////43
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1200; x < 1320; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_43->text().toInt(),ui->pushButton_43->text().toInt(),ui->pushButton_43->text().toInt(),255);
            }
    }

    for (quint32 y = 240; y < 360; ++y)///////////////44
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1320; x < 1440; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_44->text().toInt(),ui->pushButton_44->text().toInt(),ui->pushButton_44->text().toInt(),255);
            }
    }

    for (quint32 y = 240; y < 360; ++y)///////////////45
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1440; x < 1560; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_45->text().toInt(),ui->pushButton_45->text().toInt(),ui->pushButton_45->text().toInt(),255);
            }
    }
    for (quint32 y = 240; y < 360; ++y)///////////////46
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1560; x < 1680; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_46->text().toInt(),ui->pushButton_46->text().toInt(),ui->pushButton_46->text().toInt(),255);
            }
    }

    for (quint32 y = 240; y < 360; ++y)///////////////47
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1680; x < 1800; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_47->text().toInt(),ui->pushButton_47->text().toInt(),ui->pushButton_47->text().toInt(),255);
            }
    }

    for (quint32 y = 240; y < 360; ++y)///////////////48
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1800; x < 1920; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_48->text().toInt(),ui->pushButton_48->text().toInt(),ui->pushButton_48->text().toInt(),255);
            }
    }
////////***********************************************************//////////
    for (quint32 y = 360; y < 480; ++y)///////////////49
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 0; x < 120; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_49->text().toInt(),ui->pushButton_49->text().toInt(),ui->pushButton_49->text().toInt(),255);
            }
    }

    for (quint32 y = 360; y < 480; ++y)///////////////50
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 120; x < 240; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_50->text().toInt(),ui->pushButton_50->text().toInt(),ui->pushButton_50->text().toInt(),255);
            }
    }
    for (quint32 y = 360; y < 480; ++y)///////////////51
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 240; x < 360; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_51->text().toInt(),ui->pushButton_51->text().toInt(),ui->pushButton_51->text().toInt(),255);
            }
    }

    for (quint32 y = 360; y < 480; ++y)///////////////52
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 360; x < 480; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_52->text().toInt(),ui->pushButton_52->text().toInt(),ui->pushButton_52->text().toInt(),255);
            }
    }

    for (quint32 y = 360; y < 480; ++y)///////////////53
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 480; x < 600; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_53->text().toInt(),ui->pushButton_53->text().toInt(),ui->pushButton_53->text().toInt(),255);
            }
    }

    for (quint32 y = 360; y < 480; ++y)///////////////54
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 600; x < 720; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_54->text().toInt(),ui->pushButton_54->text().toInt(),ui->pushButton_54->text().toInt(),255);
            }
    }

    for (quint32 y = 360; y < 480; ++y)///////////////55
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 720; x < 840; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_55->text().toInt(),ui->pushButton_55->text().toInt(),ui->pushButton_55->text().toInt(),255);
            }
    }

    for (quint32 y = 360; y < 480; ++y)///////////////56
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 840; x < 960; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_56->text().toInt(),ui->pushButton_56->text().toInt(),ui->pushButton_56->text().toInt(),255);
            }
    }

   for (quint32 y = 360; y < 480; ++y)///////////////57
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 960; x < 1080; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_57->text().toInt(),ui->pushButton_57->text().toInt(),ui->pushButton_57->text().toInt(),255);
            }
    }

    for (quint32 y = 360; y < 480; ++y)///////////////58
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1080; x < 1200; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_58->text().toInt(),ui->pushButton_58->text().toInt(),ui->pushButton_58->text().toInt(),255);
            }
    }

    for (quint32 y = 360; y < 480; ++y)///////////////59
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1200; x < 1320; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_59->text().toInt(),ui->pushButton_59->text().toInt(),ui->pushButton_59->text().toInt(),255);
            }
    }

    for (quint32 y = 360; y < 480; ++y)///////////////60
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1320; x < 1440; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_60->text().toInt(),ui->pushButton_60->text().toInt(),ui->pushButton_60->text().toInt(),255);
            }
    }

    for (quint32 y = 360; y < 480; ++y)///////////////61
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1440; x < 1560; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_61->text().toInt(),ui->pushButton_61->text().toInt(),ui->pushButton_61->text().toInt(),255);
            }
    }
    for (quint32 y = 360; y < 480; ++y)///////////////62
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1560; x < 1680; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_62->text().toInt(),ui->pushButton_62->text().toInt(),ui->pushButton_62->text().toInt(),255);
            }
    }

    for (quint32 y = 360; y < 480; ++y)///////////////63
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1680; x < 1800; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_63->text().toInt(),ui->pushButton_63->text().toInt(),ui->pushButton_63->text().toInt(),255);
            }
    }

    for (quint32 y = 360; y < 480; ++y)///////////////64
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1800; x < 1920; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_64->text().toInt(),ui->pushButton_64->text().toInt(),ui->pushButton_64->text().toInt(),255);
            }
    }
//////***********************************************************************//////////////////////////////
    for (quint32 y = 480; y < 600; ++y)///////////////65
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 0; x < 120; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_65->text().toInt(),ui->pushButton_65->text().toInt(),ui->pushButton_65->text().toInt(),255);
            }
    }

    for (quint32 y = 480; y < 600; ++y)///////////////66
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 120; x < 240; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_66->text().toInt(),ui->pushButton_66->text().toInt(),ui->pushButton_66->text().toInt(),255);
            }
    }
    for (quint32 y = 480; y < 600; ++y)///////////////67
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 240; x < 360; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_67->text().toInt(),ui->pushButton_67->text().toInt(),ui->pushButton_67->text().toInt(),255);
            }
    }

    for (quint32 y = 480; y < 600; ++y)///////////////68
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 360; x < 480; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_68->text().toInt(),ui->pushButton_68->text().toInt(),ui->pushButton_68->text().toInt(),255);
            }
    }

    for (quint32 y = 480; y < 600; ++y)///////////////69
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 480; x < 600; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_69->text().toInt(),ui->pushButton_69->text().toInt(),ui->pushButton_69->text().toInt(),255);
            }
    }

    for (quint32 y = 480; y < 600; ++y)///////////////70
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 600; x < 720; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_70->text().toInt(),ui->pushButton_70->text().toInt(),ui->pushButton_70->text().toInt(),255);
            }
    }

    for (quint32 y = 480; y < 600; ++y)///////////////71
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 720; x < 840; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_71->text().toInt(),ui->pushButton_71->text().toInt(),ui->pushButton_71->text().toInt(),255);
            }
    }

    for (quint32 y = 480; y < 600; ++y)///////////////72
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 840; x < 960; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_72->text().toInt(),ui->pushButton_72->text().toInt(),ui->pushButton_72->text().toInt(),255);
            }
    }

   for (quint32 y = 480; y < 600; ++y)///////////////73
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 960; x < 1080; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_73->text().toInt(),ui->pushButton_73->text().toInt(),ui->pushButton_73->text().toInt(),255);
            }
    }

    for (quint32 y = 480; y < 600; ++y)///////////////74
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1080; x < 1200; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_74->text().toInt(),ui->pushButton_74->text().toInt(),ui->pushButton_74->text().toInt(),255);
            }
    }

    for (quint32 y = 480; y < 600; ++y)///////////////75
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1200; x < 1320; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_75->text().toInt(),ui->pushButton_75->text().toInt(),ui->pushButton_75->text().toInt(),255);
            }
    }

    for (quint32 y = 480; y < 600; ++y)///////////////76
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1320; x < 1440; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_76->text().toInt(),ui->pushButton_76->text().toInt(),ui->pushButton_76->text().toInt(),255);
            }
    }

    for (quint32 y = 480; y < 600; ++y)///////////////77
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1440; x < 1560; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_77->text().toInt(),ui->pushButton_77->text().toInt(),ui->pushButton_77->text().toInt(),255);
            }
    }
    for (quint32 y = 480; y < 600; ++y)///////////////78
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1560; x < 1680; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_78->text().toInt(),ui->pushButton_78->text().toInt(),ui->pushButton_78->text().toInt(),255);
            }
    }

    for (quint32 y = 480; y < 600; ++y)///////////////79
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1680; x < 1800; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_79->text().toInt(),ui->pushButton_79->text().toInt(),ui->pushButton_79->text().toInt(),255);
            }
    }

    for (quint32 y = 480; y < 600; ++y)///////////////80
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1800; x < 1920; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_80->text().toInt(),ui->pushButton_80->text().toInt(),ui->pushButton_80->text().toInt(),255);
            }
    }
/////***********************************************************/////
    for (quint32 y = 600; y < 720; ++y)///////////////81
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 0; x < 120; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_81->text().toInt(),ui->pushButton_81->text().toInt(),ui->pushButton_81->text().toInt(),255);
            }
    }

    for (quint32 y = 600; y < 720; ++y)///////////////82
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 120; x < 240; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_82->text().toInt(),ui->pushButton_82->text().toInt(),ui->pushButton_82->text().toInt(),255);
            }
    }
    for (quint32 y = 600; y < 720; ++y)///////////////83
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 240; x < 360; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_83->text().toInt(),ui->pushButton_83->text().toInt(),ui->pushButton_83->text().toInt(),255);
            }
    }

    for (quint32 y = 600; y < 720; ++y)///////////////84
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 360; x < 480; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_84->text().toInt(),ui->pushButton_84->text().toInt(),ui->pushButton_84->text().toInt(),255);
            }
    }

    for (quint32 y = 600; y < 720; ++y)///////////////85
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 480; x < 600; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_85->text().toInt(),ui->pushButton_85->text().toInt(),ui->pushButton_85->text().toInt(),255);
            }
    }

    for (quint32 y = 600; y < 720; ++y)///////////////86
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 600; x < 720; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_86->text().toInt(),ui->pushButton_86->text().toInt(),ui->pushButton_86->text().toInt(),255);
            }
    }

    for (quint32 y = 600; y < 720; ++y)///////////////87
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 720; x < 840; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_87->text().toInt(),ui->pushButton_87->text().toInt(),ui->pushButton_87->text().toInt(),255);
            }
    }

    for (quint32 y = 600; y < 720; ++y)///////////////88
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 840; x < 960; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_88->text().toInt(),ui->pushButton_88->text().toInt(),ui->pushButton_88->text().toInt(),255);
            }
    }

   for (quint32 y = 600; y < 720; ++y)///////////////89
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 960; x < 1080; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_89->text().toInt(),ui->pushButton_89->text().toInt(),ui->pushButton_89->text().toInt(),255);
            }
    }

    for (quint32 y = 600; y < 720; ++y)///////////////90
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1080; x < 1200; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_90->text().toInt(),ui->pushButton_90->text().toInt(),ui->pushButton_90->text().toInt(),255);
            }
    }

    for (quint32 y = 600; y < 720; ++y)///////////////91
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1200; x < 1320; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_91->text().toInt(),ui->pushButton_91->text().toInt(),ui->pushButton_91->text().toInt(),255);
            }
    }

    for (quint32 y = 600; y < 720; ++y)///////////////92
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1320; x < 1440; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_92->text().toInt(),ui->pushButton_92->text().toInt(),ui->pushButton_92->text().toInt(),255);
            }
    }

    for (quint32 y = 600; y < 720; ++y)///////////////93
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1440; x < 1560; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_93->text().toInt(),ui->pushButton_93->text().toInt(),ui->pushButton_93->text().toInt(),255);
            }
    }
    for (quint32 y = 600; y < 720; ++y)///////////////94
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1560; x < 1680; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_94->text().toInt(),ui->pushButton_94->text().toInt(),ui->pushButton_94->text().toInt(),255);
            }
    }

    for (quint32 y = 600; y < 720; ++y)///////////////95
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1680; x < 1800; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_95->text().toInt(),ui->pushButton_95->text().toInt(),ui->pushButton_95->text().toInt(),255);
            }
    }

    for (quint32 y = 600; y < 720; ++y)///////////////96
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1800; x < 1920; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_96->text().toInt(),ui->pushButton_96->text().toInt(),ui->pushButton_96->text().toInt(),255);
            }
    }
/////***********************************************************/////
    for (quint32 y = 720; y < 840; ++y)///////////////97
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 0; x < 120; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_97->text().toInt(),ui->pushButton_97->text().toInt(),ui->pushButton_97->text().toInt(),255);
            }
    }

    for (quint32 y = 720; y < 840; ++y)///////////////98
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 120; x < 240; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_98->text().toInt(),ui->pushButton_98->text().toInt(),ui->pushButton_98->text().toInt(),255);
            }
    }
    for (quint32 y = 720; y < 840; ++y)///////////////99
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 240; x < 360; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_99->text().toInt(),ui->pushButton_99->text().toInt(),ui->pushButton_99->text().toInt(),255);
            }
    }

    for (quint32 y = 720; y < 840; ++y)///////////////100
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 360; x < 480; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_100->text().toInt(),ui->pushButton_100->text().toInt(),ui->pushButton_100->text().toInt(),255);
            }
    }

    for (quint32 y = 720; y < 840; ++y)///////////////101
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 480; x < 600; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_101->text().toInt(),ui->pushButton_101->text().toInt(),ui->pushButton_101->text().toInt(),255);
            }
    }

    for (quint32 y = 720; y < 840; ++y)///////////////102
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 600; x < 720; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_102->text().toInt(),ui->pushButton_102->text().toInt(),ui->pushButton_102->text().toInt(),255);
            }
    }

    for (quint32 y = 720; y < 840; ++y)///////////////103
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 720; x < 840; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_103->text().toInt(),ui->pushButton_103->text().toInt(),ui->pushButton_103->text().toInt(),255);
            }
    }

    for (quint32 y = 720; y < 840; ++y)///////////////104
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 840; x < 960; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_104->text().toInt(),ui->pushButton_104->text().toInt(),ui->pushButton_104->text().toInt(),255);
            }
    }

   for (quint32 y = 720; y < 840; ++y)///////////////105
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 960; x < 1080; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_105->text().toInt(),ui->pushButton_105->text().toInt(),ui->pushButton_105->text().toInt(),255);
            }
    }

    for (quint32 y = 720; y < 840; ++y)///////////////106
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1080; x < 1200; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_106->text().toInt(),ui->pushButton_106->text().toInt(),ui->pushButton_106->text().toInt(),255);
            }
    }

    for (quint32 y = 720; y < 840; ++y)///////////////107
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1200; x < 1320; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_107->text().toInt(),ui->pushButton_107->text().toInt(),ui->pushButton_107->text().toInt(),255);
            }
    }

    for (quint32 y = 720; y < 840; ++y)///////////////108
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1320; x < 1440; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_108->text().toInt(),ui->pushButton_108->text().toInt(),ui->pushButton_108->text().toInt(),255);
            }
    }

    for (quint32 y = 720; y < 840; ++y)///////////////109
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1440; x < 1560; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_109->text().toInt(),ui->pushButton_109->text().toInt(),ui->pushButton_109->text().toInt(),255);
            }
    }
    for (quint32 y = 720; y < 840; ++y)///////////////110
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1560; x < 1680; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_110->text().toInt(),ui->pushButton_110->text().toInt(),ui->pushButton_110->text().toInt(),255);
            }
    }

    for (quint32 y = 720; y < 840; ++y)///////////////111
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1680; x < 1800; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_111->text().toInt(),ui->pushButton_111->text().toInt(),ui->pushButton_111->text().toInt(),255);
            }
    }

    for (quint32 y = 720; y < 840; ++y)///////////////112
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1800; x < 1920; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_112->text().toInt(),ui->pushButton_112->text().toInt(),ui->pushButton_112->text().toInt(),255);
            }
    }
/////***********************************************************/////
    for (quint32 y = 840; y < 960; ++y)///////////////113
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 0; x < 120; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_113->text().toInt(),ui->pushButton_113->text().toInt(),ui->pushButton_113->text().toInt(),255);
            }
    }

    for (quint32 y = 840; y < 960; ++y)///////////////114
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 120; x < 240; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_114->text().toInt(),ui->pushButton_114->text().toInt(),ui->pushButton_114->text().toInt(),255);
            }
    }
    for (quint32 y = 840; y < 960; ++y)///////////////115
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 240; x < 360; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_115->text().toInt(),ui->pushButton_115->text().toInt(),ui->pushButton_115->text().toInt(),255);
            }
    }

    for (quint32 y = 840; y < 960; ++y)///////////////116
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 360; x < 480; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_116->text().toInt(),ui->pushButton_116->text().toInt(),ui->pushButton_116->text().toInt(),255);
            }
    }

    for (quint32 y = 840; y < 960; ++y)///////////////117
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 480; x < 600; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_117->text().toInt(),ui->pushButton_117->text().toInt(),ui->pushButton_117->text().toInt(),255);
            }
    }

    for (quint32 y = 840; y < 960; ++y)///////////////118
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 600; x < 720; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_118->text().toInt(),ui->pushButton_118->text().toInt(),ui->pushButton_118->text().toInt(),255);
            }
    }

    for (quint32 y = 840; y < 960; ++y)///////////////119
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 720; x < 840; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_119->text().toInt(),ui->pushButton_119->text().toInt(),ui->pushButton_119->text().toInt(),255);
            }
    }

    for (quint32 y = 840; y < 960; ++y)///////////////120
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 840; x < 960; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_120->text().toInt(),ui->pushButton_120->text().toInt(),ui->pushButton_120->text().toInt(),255);
            }
    }

   for (quint32 y = 840; y < 960; ++y)///////////////121
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 960; x < 1080; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_121->text().toInt(),ui->pushButton_121->text().toInt(),ui->pushButton_121->text().toInt(),255);
            }
    }

    for (quint32 y = 840; y < 960; ++y)///////////////122
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1080; x < 1200; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_122->text().toInt(),ui->pushButton_122->text().toInt(),ui->pushButton_122->text().toInt(),255);
            }
    }

    for (quint32 y = 840; y < 960; ++y)///////////////123
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1200; x < 1320; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_123->text().toInt(),ui->pushButton_123->text().toInt(),ui->pushButton_123->text().toInt(),255);
            }
    }

    for (quint32 y = 840; y < 960; ++y)///////////////124
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1320; x < 1440; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_124->text().toInt(),ui->pushButton_124->text().toInt(),ui->pushButton_124->text().toInt(),255);
            }
    }

    for (quint32 y = 840; y < 960; ++y)///////////////125
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1440; x < 1560; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_125->text().toInt(),ui->pushButton_125->text().toInt(),ui->pushButton_125->text().toInt(),255);
            }
    }
    for (quint32 y = 840; y < 960; ++y)///////////////126
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1560; x < 1680; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_126->text().toInt(),ui->pushButton_126->text().toInt(),ui->pushButton_126->text().toInt(),255);
            }
    }

    for (quint32 y = 840; y < 960; ++y)///////////////127
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1680; x < 1800; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_127->text().toInt(),ui->pushButton_127->text().toInt(),ui->pushButton_127->text().toInt(),255);
            }
    }

    for (quint32 y = 840; y < 960; ++y)///////////////128
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1800; x < 1920; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_128->text().toInt(),ui->pushButton_128->text().toInt(),ui->pushButton_128->text().toInt(),255);
            }
    }
/////***********************************************************/////
    for (quint32 y = 960; y < 1080; ++y)///////////////129
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 0; x < 120; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_129->text().toInt(),ui->pushButton_129->text().toInt(),ui->pushButton_129->text().toInt(),255);
            }
    }

    for (quint32 y = 960; y < 1080; ++y)///////////////130
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 120; x < 240; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_130->text().toInt(),ui->pushButton_130->text().toInt(),ui->pushButton_130->text().toInt(),255);
            }
    }
    for (quint32 y = 960; y < 1080; ++y)///////////////131
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 240; x < 360; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_131->text().toInt(),ui->pushButton_131->text().toInt(),ui->pushButton_131->text().toInt(),255);
            }
    }

    for (quint32 y = 960; y < 1080; ++y)///////////////132
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 360; x < 480; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_132->text().toInt(),ui->pushButton_132->text().toInt(),ui->pushButton_132->text().toInt(),255);
            }
    }

    for (quint32 y = 960; y < 1080; ++y)///////////////133
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 480; x < 600; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_133->text().toInt(),ui->pushButton_133->text().toInt(),ui->pushButton_133->text().toInt(),255);
            }
    }

    for (quint32 y = 960; y < 1080; ++y)///////////////134
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 600; x < 720; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_134->text().toInt(),ui->pushButton_134->text().toInt(),ui->pushButton_134->text().toInt(),255);
            }
    }

    for (quint32 y = 960; y < 1080; ++y)///////////////135
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 720; x < 840; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_135->text().toInt(),ui->pushButton_135->text().toInt(),ui->pushButton_135->text().toInt(),255);
            }
    }

    for (quint32 y = 960; y < 1080; ++y)///////////////136
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 840; x < 960; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_136->text().toInt(),ui->pushButton_136->text().toInt(),ui->pushButton_136->text().toInt(),255);
            }
    }

   for (quint32 y = 960; y < 1080; ++y)///////////////137
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 960; x < 1080; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_137->text().toInt(),ui->pushButton_137->text().toInt(),ui->pushButton_137->text().toInt(),255);
            }
    }

    for (quint32 y = 960; y < 1080; ++y)///////////////138
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1080; x < 1200; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_138->text().toInt(),ui->pushButton_138->text().toInt(),ui->pushButton_138->text().toInt(),255);
            }
    }

    for (quint32 y = 960; y < 1080; ++y)///////////////139
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1200; x < 1320; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_139->text().toInt(),ui->pushButton_139->text().toInt(),ui->pushButton_139->text().toInt(),255);
            }
    }

    for (quint32 y = 960; y < 1080; ++y)///////////////140
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1320; x < 1440; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_140->text().toInt(),ui->pushButton_140->text().toInt(),ui->pushButton_140->text().toInt(),255);
            }
    }

    for (quint32 y = 960; y < 1080; ++y)///////////////141
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1440; x < 1560; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_141->text().toInt(),ui->pushButton_141->text().toInt(),ui->pushButton_141->text().toInt(),255);
            }
    }
    for (quint32 y = 960; y < 1080; ++y)///////////////142
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1560; x < 1680; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_142->text().toInt(),ui->pushButton_142->text().toInt(),ui->pushButton_142->text().toInt(),255);
            }
    }

    for (quint32 y = 960; y < 1080; ++y)///////////////143
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1680; x < 1800; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_143->text().toInt(),ui->pushButton_143->text().toInt(),ui->pushButton_143->text().toInt(),255);
            }
    }

    for (quint32 y = 960; y < 1080; ++y)///////////////144
    {
            QRgb *scanLine = (QRgb *)mMask.scanLine(y);
            for (quint32 x = 1800; x < 1920; ++x)
            {
                scanLine[x] = qRgba(ui->pushButton_144->text().toInt(),ui->pushButton_144->text().toInt(),ui->pushButton_144->text().toInt(),255);
            }
    }
/////***********************************************************/////


}

