#include "maskbutton.h"

MaskButton::MaskButton(QWidget *parent) :
    QPushButton(parent)
{
    multiple=1;
    connect(this,SIGNAL(leftbutton()),this,SLOT(leftbuttonhandle()));
    connect(this,SIGNAL(rightbutton()),this,SLOT(rightbuttonhandle()));
}

void MaskButton::mouseReleaseEvent(QMouseEvent *e)
{
    if(e->button() == Qt::LeftButton)
    {
       emit leftbutton();
    }

       else if(e->button() == Qt::RightButton)
    {
       emit rightbutton();
    }
}

void MaskButton::leftbuttonhandle()
{
     val=this->text().toInt()+multiple;
     if(val>255)val=255;
     if(val<100)val=100;
     this->setText(QString::number(val));
}
void MaskButton::rightbuttonhandle()
{
    val=this->text().toInt()-multiple;
    if(val>255)val=255;
    if(val<100)val=100;
    this->setText(QString::number(val));
}
