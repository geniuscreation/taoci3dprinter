This Folder Contains Application Icons needed in the B9Creator.pro file.
For Windows and Mac, Qt will automatically use the icons when compiling.
For Linux Icons - See the Deployment directory.