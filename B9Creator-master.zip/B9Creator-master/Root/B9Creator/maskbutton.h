#ifndef MASKBUTTON_H
#define MASKBUTTON_H

#include <QPushButton>
#include <QMouseEvent>

class MaskButton : public QPushButton
{
    Q_OBJECT
public:
    explicit MaskButton(QWidget *parent = 0);
    int val;
    int multiple;

protected:
    void mouseReleaseEvent(QMouseEvent *e);

signals:
    void leftbutton();
    void rightbutton();

public slots:
    void leftbuttonhandle();
    void rightbuttonhandle();

};

#endif // MASKBUTTON_H
