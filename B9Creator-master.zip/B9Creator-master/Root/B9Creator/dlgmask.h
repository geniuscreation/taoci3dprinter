#ifndef DLGMASK_H
#define DLGMASK_H

#include <QDialog>

namespace Ui {
class DlgMask;
}

class DlgMask : public QDialog
{
    Q_OBJECT

public:
    explicit DlgMask(QWidget *parent = 0);
    ~DlgMask();
    void creategeneralMask();
    QImage mMask;

private slots:
    void on_comboBox_activated(const QString &arg1);

    void on_pushButton_145_clicked();


private:
    Ui::DlgMask *ui;
};

#endif // DLGMASK_H
